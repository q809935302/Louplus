for i in range(1,100):
    if ((i==7) or ((i%7) == 0 )):
        continue
    print(i)
